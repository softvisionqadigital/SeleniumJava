package Demos;

import org.testng.annotations.Test;

import com.learningDemo.FrameHandling_demo;

public class Frames {
	
	
	@Test
	public void handlingFrames() {
		
		FrameHandling_demo obj = new FrameHandling_demo();
		
		obj.frameHandling();
	}

}
